

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import session_tracking.EmpDao;


@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	
	{
		
		res.setContentType("text/html");
		PrintWriter out =res.getWriter();
		
		int id =Integer.getInteger(req.getParameter("id").intValue());
		String name =req.getParameter("name");
		int salary =Integer.getInteger(req.getParameter("salary").intValue());
		
		Emp e = new Emp();
		e.setId(id);
		e.setName(name);
		e.setsalary(salary);
		
		int status =EmpDao.save(e);
		if (status>0)
			
		{
			out.print("<p> Record Saved Successfully</p>");
			req.getRequestDispatcher("crud.html").include(req, res);
			
		}else 
		{
			out.println("Sorry unable to save record");
		}
		
		out.close();
		
	}
}
